/** Request Desk — a Google Sheets-backed internal workflow starter.
 * This is NOT a production authorization or audit system.
 * Deploy to the right authenticated audience only; review permissions before sharing.
 */
const REQUESTS_SHEET = 'Requests';
const HEADERS = [
  'ID', 'Created At', 'Updated At', 'Request', 'Category', 'Owner',
  'Priority', 'Status', 'Due Date', 'Next Action'
];
const STATUSES = ['New', 'Assigned', 'In Progress', 'Blocked', 'Complete', 'Cancelled'];
const PRIORITIES = ['Low', 'Medium', 'High', 'Critical'];

function setupRequestSheet() {
  const spreadsheet = SpreadsheetApp.getActiveSpreadsheet();
  if (!spreadsheet) throw new Error('Bind this script to a Google Spreadsheet first.');
  const sheet = spreadsheet.getSheetByName(REQUESTS_SHEET) || spreadsheet.insertSheet(REQUESTS_SHEET);
  const firstRow = sheet.getRange(1, 1, 1, HEADERS.length).getDisplayValues()[0];
  const empty = firstRow.every(value => !value);
  if (!empty && !HEADERS.every((name, i) => firstRow[i] === name)) {
    throw new Error('Existing Requests columns do not match. Do not overwrite business data.');
  }
  if (empty) sheet.getRange(1, 1, 1, HEADERS.length).setValues([HEADERS]);
  sheet.setFrozenRows(1);
  sheet.getRange(1, 1, 1, HEADERS.length).setBackground('#0b1220').setFontColor('#ffffff').setFontWeight('bold');
  sheet.getRange('B:C').setNumberFormat('yyyy-mm-dd hh:mm');
  sheet.getRange('I:I').setNumberFormat('yyyy-mm-dd');
  return 'Request sheet ready';
}

function doGet() {
  return HtmlService.createTemplateFromFile('Index').evaluate().setTitle('Request Desk');
}

function include(filename) {
  return HtmlService.createHtmlOutputFromFile(filename).getContent();
}

function requestSheet_() {
  const spreadsheet = SpreadsheetApp.getActiveSpreadsheet();
  if (!spreadsheet) throw new Error('The bound spreadsheet is unavailable.');
  const sheet = spreadsheet.getSheetByName(REQUESTS_SHEET);
  if (!sheet) throw new Error('Run setupRequestSheet() once first.');
  const actual = sheet.getRange(1, 1, 1, HEADERS.length).getDisplayValues()[0];
  if (!HEADERS.every((header, index) => actual[index] === header)) {
    throw new Error('The Requests header order changed. Restore it before using the app.');
  }
  return sheet;
}

function asText_(input, maxLength) {
  const value = String(input === null || input === undefined ? '' : input).trim().slice(0, maxLength);
  // Avoid user-supplied spreadsheet formulas becoming active cell formulas.
  return /^[=+\-@]/.test(value) ? "'" + value : value;
}

function dateInput_(input) {
  if (!input) return '';
  const value = String(input);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) throw new Error('Due date must be YYYY-MM-DD.');
  const date = new Date(value + 'T12:00:00');
  if (Number.isNaN(date.getTime()) || Utilities.formatDate(date, Session.getScriptTimeZone(), 'yyyy-MM-dd') !== value) {
    throw new Error('Invalid due date.');
  }
  return date;
}

function listRequests() {
  const sheet = requestSheet_();
  const rowCount = Math.min(Math.max(sheet.getLastRow() - 1, 0), 1000);
  if (!rowCount) return [];
  const rows = sheet.getRange(2, 1, rowCount, HEADERS.length).getDisplayValues();
  return rows.filter(row => row[0]).map(row => ({
    id: row[0], createdAt: row[1], updatedAt: row[2],
    request: row[3], category: row[4], owner: row[5],
    priority: row[6], status: row[7], dueDate: row[8], nextAction: row[9]
  })).reverse();
}

function createRequest(payload) {
  if (!payload || typeof payload !== 'object') throw new Error('Request data is required.');
  const name = asText_(payload.request, 160);
  if (name.length < 3) throw new Error('Please enter a request of at least 3 characters.');
  const status = STATUSES.includes(payload.status) ? payload.status : 'New';
  const priority = PRIORITIES.includes(payload.priority) ? payload.priority : 'Medium';
  const category = asText_(payload.category, 60) || 'General';
  const owner = asText_(payload.owner, 80);
  const next = asText_(payload.nextAction, 250);
  const date = dateInput_(payload.dueDate);
  const lock = LockService.getDocumentLock() || LockService.getScriptLock();
  if (!lock.tryLock(10000)) throw new Error('The tracker is busy. Please try again.');
  try {
    const sheet = requestSheet_();
    const id = 'REQ-' + Utilities.getUuid().replace(/-/g, '').slice(0, 10).toUpperCase();
    const existing = sheet.getLastRow() > 1 ? sheet.getRange(2, 1, sheet.getLastRow() - 1, 1).getDisplayValues().flat() : [];
    if (existing.includes(id)) throw new Error('ID collision. Try again.');
    const now = new Date();
    sheet.appendRow([id, now, now, name, category, owner, priority, status, date, next]);
    return { id, message: 'Request created' };
  } finally {
    lock.releaseLock();
  }
}

function updateRequest(id, patch) {
  if (!/^REQ-[A-Z0-9]{8,20}$/.test(String(id))) throw new Error('Invalid request ID.');
  if (!patch || typeof patch !== 'object') throw new Error('Update data is required.');
  const keys = Object.keys(patch);
  if (!keys.length || keys.some(k => !['owner','priority','status','dueDate','nextAction'].includes(k))) {
    throw new Error('Unsupported field update.');
  }
  const lock = LockService.getDocumentLock() || LockService.getScriptLock();
  if (!lock.tryLock(10000)) throw new Error('The tracker is busy. Please try again.');
  try {
    const sheet = requestSheet_();
    const last = sheet.getLastRow();
    if (last < 2) throw new Error('No requests found.');
    const ids = sheet.getRange(2, 1, last - 1, 1).getDisplayValues().flat();
    const index = ids.indexOf(id);
    if (index < 0) throw new Error('This request no longer exists. Refresh the page.');
    const rowNumber = index + 2;
    const column = {owner:6,priority:7,status:8,dueDate:9,nextAction:10};
    keys.forEach(key => {
      let value = patch[key];
      if (key === 'status' && !STATUSES.includes(value)) throw new Error('Invalid status.');
      if (key === 'priority' && !PRIORITIES.includes(value)) throw new Error('Invalid priority.');
      if (key === 'owner') value = asText_(value, 80);
      if (key === 'nextAction') value = asText_(value, 250);
      if (key === 'dueDate') value = dateInput_(value);
      sheet.getRange(rowNumber, column[key]).setValue(value);
    });
    sheet.getRange(rowNumber, 3).setValue(new Date());
    return { id, message: 'Request updated' };
  } finally {
    lock.releaseLock();
  }
}
